/*******************************************************************************
 * Project     : PF_MiV_WiFi_Demo
 * File        : main.c
 *
 * Description : The Avalanche WiFi demo features some basic features from
 * 							 the Panasonic Wi-Fi 9320 module being the Access Point (AP)
 * 							 and the Netcat data tunneling service.
 *
 * 							 The FPGA Pan9320 interface is used through a Mi-V softcore
 * 							 implementing a basic driver.
 *
 * 							 Upon power-up of the board, the Wi-Fi module is configured
 * 							 for communication between the board and a remote PC using the
 * 							 Netcat data tunneling service. An 0.5Hz heartbeat is active on
 * 							 LED2 red.
 *
 * 							 Depression of pushbutton #1 will activate the demo. Depression
 * 							 of pushbutton #2 will send LED status to the remote PC using
 * 							 the Wi-Fi module. For more details on the different commands
 * 							 and required setup, see the Design Description PDF document
 * 							 provided with the demo.
 *
 * 							 Terminal setup (Host): Serial, 115200/8/1, no parity,
 * 							 no flow control.
 *
 * Created on  : June 29, 2018
 * Author      : Frederic.Vachon  
 *
 * (c) Copyright 2018 Future Electronics - Advanced Engineering Group
 *     All rights reserved
 *
 * DISCLAIMER OF WARRANTY
 * All materials, information and services are provided “as-is” and “as-available”
 * for your use. Future Electronics disclaims all warranties of any kind, either
 * express or implied, including but not limited to, the implied warranties of
 * merchantability and fitness for a particular purpose, title, or non-infringement.
 * You acknowledge and agree that the reference designs and other such design
 * materials included herein are provided as an example only and that you will
 * exercise your own independent analysis and judgment in your use of these
 * materials. Future Electronics assumes no liability for your use of these
 * materials for your product designs.
 *
 * INDEMNIFICATION
 * You agree to indemnify, defend and hold Future Electronics and all of its
 * agents, directors, employees, information providers, licensors and licensees,
 * and affiliated companies (collectively, “Indemnified Parties”), harmless from
 * and against any and all liability and costs (including, without limitation,
 * attorneys’ fees and costs), incurred by the Indemnified Parties in connection
 * with any claim arising out of any breach by You of these Terms and Conditions 
 * of Use or any representations or warranties made by You herein. You will
 * cooperate as fully as reasonably required in Future Electronics’ defense of
 * any claim. Future Electronics reserves the right, at its own expense, to
 * assume the exclusive defense and control of any matter otherwise subject to
 * indemnification by You and You shall not in any event settle any matter
 * without the written consent of Future Electronics.
 *
 * LIMITATION OF LIABILITY
 * Under no circumstances shall Future Electronics, nor its agents, directors,
 * employees, information providers, licensors and licensee, and affiliated
 * companies be liable for any damages, including without limitation, direct,
 * indirect, incidental, special, punitive, consequential, or other damages
 * (including without limitation lost profits, lost revenues, or similar economic
 * loss), whether in contract, tort, or otherwise, arising out of the use or
 * inability to use the materials provided as a reference design, even if we
 * are advised of the possibility thereof, nor for any claim by a third party.
 ******************************************************************************/
#include <string.h>

#include "riscv_hal.h"
#include "hw_platform.h"
#include "BasicIO.h"
#include "Pan9320.h"

// -- Constants --------------------------------------------------------------
char *g_MSG_INTRO =
		"\n\r(C) Copyright 2018 Future Electronics - Avalanche Board\n\r";

char *g_MSG_DEMO =
		"\n\rBasic Wi-Fi Demo"
		"\n\r  Send commands from a terminal on a remote PC to control the"
		"\n\r  LEDs and the Heartbeat."
		"\n\r    Depress PB#1 to activate the demo after Heartbeat is on"
		"\n\r    Depress PB#2 to send the LED statuses to the remote PC.\n\r";

char *g_CRLF = "\n\r";

#define IDLE_1					0x01
#define IDLE_2					0x02
#define IDLE_3					0x03
#define RX_1 						0x04
#define RX_2     				0x05
#define TX_1      			0x06
#define TX_2       			0x07

// -- Global variables -------------------------------------------------------

// -- Local variables --------------------------------------------------------
uint8_t HB_active;
static char State;

/*----------------------------------------------------------------------------
 * System Tick Interrupt Handler (Heartbeat)
 */
void SysTick_Handler(void) {

	uint32_t gpio_pattern_leds;

	if (HB_active == 1) {
		gpio_pattern_leds = getLEDsPattern();
		gpio_pattern_leds &= 0x00000020;
		if (gpio_pattern_leds == 0x0) { 		// LED on?
			clearLED2_RED();
		} else {
			setLED2_RED();
		}
	}
}

/*----------------------------------------------------------------------------
 * User Pushbutton #1 Interrupt Handler (Start Demo)
 */
void External_31_IRQHandler() {
	clearPB1_IRQ();
	State = IDLE_2;
	PLIC_CompleteIRQ(PLIC_ClaimIRQ());
}

/*----------------------------------------------------------------------------
 * User Pushbutton #2 Interrupt Handler (LED Status report)
 */
void External_30_IRQHandler() {
	clearPB2_IRQ();
	State = TX_2;
	PLIC_CompleteIRQ(PLIC_ClaimIRQ());
}

/*----------------------------------------------------------------------------
 * main
 */
int main() {

  uint8_t rx_char_data[1];
  uint8_t rx_count_data;
  uint8_t tx_char_data[1];
  uint8_t tx_count_data;

  uint8_t count = 0;
  uint8_t data[22];

	uint32_t led_status;

	uint8_t *textOut;

	HB_active = 1;
	State = IDLE_1;

  /* PLIC controller setup */
  PLIC_init();

 	PLIC_SetPriority(IRQ30_PB1, 1);
 	PLIC_EnableIRQ(IRQ30_PB1);

 	PLIC_SetPriority(IRQ29_PB2, 2);
 	PLIC_EnableIRQ(IRQ29_PB2);

 	// -- Block setup ------------------------------------------------------------

 	BasicIO_Init(BASIC_IO_ADDR);
 	PAN_Init(PAN9320_GPIO_ADDR);

  // Main process

  PAN_Enable();
  PAN_Config_NetCat();

  // System Timer setup
  SysTick_Config(SYS_CLK_FREQ/2);

  do {
  	switch(State) {

			case IDLE_1: {
				break;
			}

			case IDLE_2: {
				UART_Tx_Msg(g_MSG_INTRO, 1);
				UART_Tx_Msg(g_MSG_DEMO, 1);
				State = IDLE_3;
				break;
			}

			case IDLE_3: {
				// Send data to the Netcat UART (Wi-Fi)
				tx_count_data = UART_Rx_Msg(tx_char_data);
	      if (tx_count_data > 0) {
	      	State = TX_1;
	      }

				// Receive data from the NETcat UART (Wi-Fi)
				rx_count_data = PAN_ReceiveData(rx_char_data);
				if (rx_count_data > 0) {
					State = RX_1;
	      }
				break;
			}
			case RX_1: {		// Grabbing 1 received char at a time
				if (rx_char_data[0] != '\r' && count < 20) {
					data[count] = rx_char_data[0];
					count++;
					State = IDLE_3;
				} else {
					data[count] = '\0';
					State = RX_2;
				}
				break;
			}
			case RX_2: {
				State = IDLE_3;

				if (strncmp(data, "LED1 green on", 13) == 0) {
					setLED1_GREEN();
				}
				if (strncmp(data, "LED1 green off", 14) == 0) {
					clearLED1_GREEN();
				}
				if (strncmp(data, "LED1 red on", 11) == 0) {
					setLED1_RED();
				}
				if (strncmp(data, "LED1 red off", 12) == 0) {
					clearLED1_RED();
				}
				if (strncmp(data, "LED2 green on", 13) == 0) {
					setLED2_GREEN();
				}
				if (strncmp(data, "LED2 green off", 14) == 0) {
					clearLED2_GREEN();
				}
				if (strncmp(data, "Heartbeat off", 13) == 0) {
					HB_active = 0;
					clearLED2_RED();
				}
				if (strncmp(data, "Heartbeat on", 12) == 0) {
					HB_active = 1;
				}

				if (strncmp(data, "LED status", 10) == 0) {
					State = TX_2;
				}

				UART_Tx_Msg(data, 1);		// Echo received command to the Terminal
				UART_Tx_Msg(g_CRLF, 1);

				memset(data, 0, sizeof(data));
				count = 0;
				break;
			}

			case TX_1: {		// Accumulate 1 char at a time for Wi-Fi TX
				if (tx_char_data[0] != '\r' && count < 20) {
					data[count] = tx_char_data[0];
					count++;
					State = IDLE_3;
				} else {
					data[count] = '\n';
					data[++count] = '\r';
					PAN_SendData(data, ++count);
					UART_Tx_Msg(data, 1);

					count = 0;
					memset(data, 0, sizeof(data));
					State = IDLE_3;
				}
				break;
			}

			case TX_2: {
				textOut = "\n\rLED1 status\n\r";
				PAN_SendData(textOut, strlen(textOut));

				led_status = getLEDsPattern();
				led_status &= 0x00000004;
				if (led_status == 0x0) { 		// LED1 green on?
					textOut = "  Green: on\n\r";
					PAN_SendData(textOut, strlen(textOut));
				} else {
					textOut = "  Green: off\n\r";
					PAN_SendData(textOut, strlen(textOut));
				}

				led_status = getLEDsPattern();
				led_status &= 0x00000008;
				if (led_status == 0x0) { 		// LED1 red on?
					textOut = "  Red: on\n\r";
					PAN_SendData(textOut, strlen(textOut));
				} else {
					textOut = "  Red: off\n\r";
					PAN_SendData(textOut, strlen(textOut));
				}

				textOut = "\n\rLED2 status\n\r";
				PAN_SendData(textOut, strlen(textOut));

				led_status = getLEDsPattern();
				led_status &= 0x00000010;
				if (led_status == 0x0) { 		// LED2 green on?
					textOut = "  Green: on\n\r";
					PAN_SendData(textOut, strlen(textOut));
				} else {
					textOut = "  Green: off\n\r";
					PAN_SendData(textOut, strlen(textOut));
				}

				if (HB_active == 1) { 		// LED2 red heartbeat on?
					textOut = "  Heartbeat active on Red\n\r\n\r";
					PAN_SendData(textOut, strlen(textOut));
				} else {
					textOut = "  No Heartbeat on Red\n\r\n\r";
					PAN_SendData(textOut, strlen(textOut));
				}

				State = IDLE_3;
				break;
			}

			default: {
				State = IDLE_1;
				break;
			}
  	}
  } while (1);

  return 0;
}


