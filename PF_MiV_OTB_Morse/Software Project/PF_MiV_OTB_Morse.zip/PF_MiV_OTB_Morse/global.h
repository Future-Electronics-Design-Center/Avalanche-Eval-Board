/*****************************************************************************
 * Project     : PF_RISCV_OTB_MORSE
 * File        : global.h
 *
 * Description : This file contains the global declarations required by the
 * 							 OTB Demo.
 *
 * Created on  : Feb 19, 2018
 * Author      : Frederic.Vachon  
 *
 * (c) Copyright 2018 Future Electronics - Advanced Engineering Group
 *     All rights reserved
 *
 * DISCLAIMER OF WARRANTY
 * All materials, information and services are provided “as-is” and “as-available”
 * for your use. Future Electronics disclaims all warranties of any kind, either
 * express or implied, including but not limited to, the implied warranties of
 * merchantability and fitness for a particular purpose, title, or non-infringement.
 * You acknowledge and agree that the reference designs and other such design
 * materials included herein are provided as an example only and that you will
 * exercise your own independent analysis and judgment in your use of these
 * materials. Future Electronics assumes no liability for your use of these
 * materials for your product designs.
 *
 * INDEMNIFICATION
 * You agree to indemnify, defend and hold Future Electronics and all of its
 * agents, directors, employees, information providers, licensors and licensees,
 * and affiliated companies (collectively, “Indemnified Parties”), harmless from
 * and against any and all liability and costs (including, without limitation,
 * attorneys’ fees and costs), incurred by the Indemnified Parties in connection
 * with any claim arising out of any breach by You of these Terms and Conditions
 * of Use or any representations or warranties made by You herein. You will
 * cooperate as fully as reasonably required in Future Electronics’ defense of
 * any claim. Future Electronics reserves the right, at its own expense, to
 * assume the exclusive defense and control of any matter otherwise subject to
 * indemnification by You and You shall not in any event settle any matter
 * without the written consent of Future Electronics.
 *
 * LIMITATION OF LIABILITY
 * Under no circumstances shall Future Electronics, nor its agents, directors,
 * employees, information providers, licensors and licensee, and affiliated
 * companies be liable for any damages, including without limitation, direct,
 * indirect, incidental, special, punitive, consequential, or other damages
 * (including without limitation lost profits, lost revenues, or similar economic
 * loss), whether in contract, tort, or otherwise, arising out of the use or
 * inability to use the materials provided as a reference design, even if we
 * are advised of the possibility thereof, nor for any claim by a third party.
 ****************************************************************************/

#ifndef GLOBAL_H_
#define GLOBAL_H_

#include "riscv_hal.h"
#include "hw_platform.h"
#include "core_gpio.h"
#include "core_uart_apb.h"
#include "core_timer.h"

// -- Definitions ------------------------------------------------------------

#define PB1							GPIO_0
#define PB2							GPIO_1

#define LED1_GREEN			GPIO_2
#define LED1_RED				GPIO_3
#define LED2_GREEN			GPIO_4
#define LED2_RED				GPIO_5
#define LED_ON				 	0
#define LED_OFF					1

#define CLKS_ENABLED		GPIO_6
#define CLKS_ON					1
#define CLKS_OFF				0

#define TIMER_MS_REF		50


// -- Global functions -------------------------------------------------------

extern void Delay (int msec);


#endif /* GLOBAL_H_ */
