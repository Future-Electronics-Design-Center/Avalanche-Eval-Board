/*******************************************************************************
 * Project     : PF_MiV_OTB_Morse
 * File        : main.c
 *
 * Description : The Avalanche Out-of-The-Box demo features some of available
 * 							 interfaces used through a Mi-V softcore. The program has two
 * 							 functions: a BIT (Built-In Test) and a Morse emitter.
 *
 * 							 Upon power-up of the board, a basic BIT is launch then the
 * 							 board will show an heartbeat on LED2 green. Both the BIT and
 * 							 Morse emitter functions will be available through a Terminal
 * 							 connection.
 *
 * 							 Holding pushbutton #2 for more than two seconds will activate
 * 							 the CM (production) tests. The only way to stop the CM tests
 * 							 is to reset the board.
 *
 * 							 Terminal setup: Serial Terminal, 115200/8/1, no parity,
 * 							 no flow control.
 *
 * Created on  : Feb 19, 2018
 * Author      : Frederic.Vachon  
 *
 * (c) Copyright 2018 Future Electronics - Advanced Engineering Group
 *     All rights reserved
 *
 * DISCLAIMER OF WARRANTY
 * All materials, information and services are provided “as-is” and “as-available”
 * for your use. Future Electronics disclaims all warranties of any kind, either
 * express or implied, including but not limited to, the implied warranties of
 * merchantability and fitness for a particular purpose, title, or non-infringement.
 * You acknowledge and agree that the reference designs and other such design
 * materials included herein are provided as an example only and that you will
 * exercise your own independent analysis and judgment in your use of these
 * materials. Future Electronics assumes no liability for your use of these
 * materials for your product designs.
 *
 * INDEMNIFICATION
 * You agree to indemnify, defend and hold Future Electronics and all of its
 * agents, directors, employees, information providers, licensors and licensees,
 * and affiliated companies (collectively, “Indemnified Parties”), harmless from
 * and against any and all liability and costs (including, without limitation,
 * attorneys’ fees and costs), incurred by the Indemnified Parties in connection
 * with any claim arising out of any breach by You of these Terms and Conditions 
 * of Use or any representations or warranties made by You herein. You will
 * cooperate as fully as reasonably required in Future Electronics’ defense of
 * any claim. Future Electronics reserves the right, at its own expense, to
 * assume the exclusive defense and control of any matter otherwise subject to
 * indemnification by You and You shall not in any event settle any matter
 * without the written consent of Future Electronics.
 *
 * LIMITATION OF LIABILITY
 * Under no circumstances shall Future Electronics, nor its agents, directors,
 * employees, information providers, licensors and licensee, and affiliated
 * companies be liable for any damages, including without limitation, direct,
 * indirect, incidental, special, punitive, consequential, or other damages
 * (including without limitation lost profits, lost revenues, or similar economic
 * loss), whether in contract, tort, or otherwise, arising out of the use or
 * inability to use the materials provided as a reference design, even if we
 * are advised of the possibility thereof, nor for any claim by a third party.
 ******************************************************************************/

#include "global.h"
#include "Pan9320.h"
#include "morse.h"
#include "BIT.h"

// -- Constants --------------------------------------------------------------
const char *g_MSG_INTRO =
		"\n\r(C) Copyright 2018 Future Electronics - Avalanche Board\n\r";

const char *g_MSG_DEMO =
		"\n\rOut-of-the-Box Demo"
		"\n\r  Press PB1 to start/stop the Morse emitter"
		"\n\r  Press PB2 to start the Built-In Test\n\r";

const char *g_MSG_CM_TEST =
		"\n\rProduction Test Mode"
		"\n\r  Press RESET to exit\n\r";

const char *g_MSG_MORSE_ON = "\n\rMorse Emitter on\n\r";
const char *g_MSG_MORSE_OFF = "\n\rMorse Emitter off\n\r";

#define STATE_IDLE			0x01
#define STATE_BIT				0x02
#define STATE_MORSE1		0x03
#define STATE_MORSE2		0x04
#define STATE_CM1       0x05
#define STATE_CM2       0x06
#define STATE_CM3    		0x07

// -- UART instance data -----------------------------------------------------
UART_instance_t g_uart_term;

// -- Timer instance data -----------------------------------------------------
timer_instance_t g_timer_delay;

// -- GPIO instance data -----------------------------------------------------
gpio_instance_t g_gpio_in_pbs;
gpio_instance_t g_gpio_out_leds;
gpio_instance_t g_gpio_Pan9320;

// -- Global variables -------------------------------------------------------
uint8_t g_timer_irq;
uint8_t g_CM_PB_test;

// -- Local variables --------------------------------------------------------
uint8_t BIT_inProgress;
uint8_t morse_status;
uint32_t count;

uint32_t tstamp1;

static char State;

/*----------------------------------------------------------------------------
 * System Tick Interrupt Handler (Heartbeat)
 */
void SysTick_Handler(void) {

	uint32_t gpio_pattern_leds;

	switch(BIT_inProgress) {
		case 0: {
			// LED 2 Green heartbeat
			gpio_pattern_leds = GPIO_get_outputs(&g_gpio_out_leds);
			gpio_pattern_leds &= 0x00000010;
			if (gpio_pattern_leds == 0x0) { 		// LED on?
				GPIO_set_output(&g_gpio_out_leds, LED2_GREEN, LED_OFF);
			} else {
				GPIO_set_output(&g_gpio_out_leds, LED2_GREEN, LED_ON);
			}
			break;
		}
		case 1: {
			break;
		}
		case 2: {
			// LEDs heartbeat
			if (g_CM_PB_test == 0) {
				gpio_pattern_leds = GPIO_get_outputs(&g_gpio_out_leds);
				gpio_pattern_leds &= 0x00000014;
				if (gpio_pattern_leds == 0x0) { 		// LEDs green on?
					GPIO_set_output(&g_gpio_out_leds, LED1_GREEN, LED_OFF);
					GPIO_set_output(&g_gpio_out_leds, LED2_GREEN, LED_OFF);
					GPIO_set_output(&g_gpio_out_leds, LED1_RED, LED_ON);
					GPIO_set_output(&g_gpio_out_leds, LED2_RED, LED_ON);
				} else {
					GPIO_set_output(&g_gpio_out_leds, LED1_GREEN, LED_ON);
					GPIO_set_output(&g_gpio_out_leds, LED2_GREEN, LED_ON);
					GPIO_set_output(&g_gpio_out_leds, LED1_RED, LED_OFF);
					GPIO_set_output(&g_gpio_out_leds, LED2_RED, LED_OFF);
				}
				break;
			}
		}
	}
	count++;
}

/*----------------------------------------------------------------------------
 * User Pushbutton #1 Interrupt Handler (Morse emitter)
 */
void External_31_IRQHandler() {

	if (BIT_inProgress == 0) {
		State = STATE_MORSE1;
	}
	GPIO_clear_irq(&g_gpio_in_pbs, PB1);
	PLIC_CompleteIRQ(PLIC_ClaimIRQ());
}

/*----------------------------------------------------------------------------
 * User Pushbutton #2 Interrupt Handler (Built-in Test)
 */
void External_30_IRQHandler() {

	State = STATE_CM1;
	GPIO_clear_irq(&g_gpio_in_pbs, PB2);
	PLIC_CompleteIRQ(PLIC_ClaimIRQ());
}

/*----------------------------------------------------------------------------
 * Delay Timer Interrupt Handler
 */
void External_29_IRQHandler() {
	g_timer_irq = 1;
	TMR_clear_int(&g_timer_delay);
	PLIC_CompleteIRQ(PLIC_ClaimIRQ());
}

/*----------------------------------------------------------------------------
 * main
 */
int main() {

	uint8_t rx_char;
  uint8_t rx_count;

	uint32_t pb_read;
	uint32_t pb_stable;

	g_timer_irq = 0;
	g_CM_PB_test = 0;
	BIT_inProgress = 0;
	morse_status = 0;
	count = 0;
	tstamp1 = 0;
	State = STATE_IDLE;

  /* PLIC controller setup */

  PLIC_init();

 	PLIC_SetPriority(IRQ30_PB1, 3);
 	PLIC_EnableIRQ(IRQ30_PB1);

 	PLIC_SetPriority(IRQ29_PB2, 2);
 	PLIC_EnableIRQ(IRQ29_PB2);

 	PLIC_SetPriority(IRQ28_TIMER, 1);
 	PLIC_EnableIRQ(IRQ28_TIMER);

 	// -- GPIO setup -------------------------------------------------------------

 	GPIO_init(&g_gpio_in_pbs, COREGPIO_BASIC_ADDR, GPIO_APB_32_BITS_BUS);
 	GPIO_init(&g_gpio_out_leds, COREGPIO_BASIC_ADDR, GPIO_APB_32_BITS_BUS);
 	GPIO_init(&g_gpio_Pan9320, COREGPIO_PAN9320_ADDR, GPIO_APB_32_BITS_BUS);

  // User PB#1
  GPIO_config(&g_gpio_in_pbs, PB1, GPIO_INPUT_MODE | GPIO_IRQ_EDGE_POSITIVE);
  GPIO_enable_irq(&g_gpio_in_pbs, PB1);
  // User PB#2
  GPIO_config(&g_gpio_in_pbs, PB2, GPIO_INPUT_MODE | GPIO_IRQ_EDGE_NEGATIVE);
  GPIO_enable_irq(&g_gpio_in_pbs, PB2);
  // LED 1
  GPIO_config(&g_gpio_out_leds, LED1_GREEN, GPIO_OUTPUT_MODE);
  GPIO_config(&g_gpio_out_leds, LED1_RED, GPIO_OUTPUT_MODE);

  GPIO_set_output(&g_gpio_out_leds, LED1_GREEN, LED_OFF);
  GPIO_set_output(&g_gpio_out_leds, LED1_RED, LED_OFF);

  // LED 2
  GPIO_config(&g_gpio_out_leds, LED2_GREEN, GPIO_OUTPUT_MODE);
  GPIO_config(&g_gpio_out_leds, LED2_RED, GPIO_OUTPUT_MODE);

  GPIO_set_output(&g_gpio_out_leds, LED2_GREEN, LED_OFF);
  GPIO_set_output(&g_gpio_out_leds, LED2_RED, LED_OFF);

  // Pan9320 Wifi module
  GPIO_config(&g_gpio_Pan9320, FACT_RST, GPIO_OUTPUT_MODE);
  GPIO_config(&g_gpio_Pan9320, RESETn, GPIO_OUTPUT_MODE);

  GPIO_set_output(&g_gpio_Pan9320, FACT_RST, FACT_RST_OFF);
  GPIO_set_output(&g_gpio_Pan9320, RESETn, RESET_ON);

  // Terminal UART setup
  UART_init(&g_uart_term,
  					COREUART_TERM_ADDR,
						BAUD_VALUE_115200,
            (DATA_8_BITS | NO_PARITY));

  // Delay Timer setup
  TMR_init(&g_timer_delay,
  				 CORETIMER0_ADDR,
					 TMR_ONE_SHOT_MODE,
           PRESCALER_DIV_1024, // (50MHZ / 1024) ~ 50kHz
           0);
  TMR_enable_int(&g_timer_delay);
  TMR_start(&g_timer_delay);

  // System Timer setup
  SysTick_Config(SYS_CLK_FREQ/2);

	// Deactivate external clocks outputs
	GPIO_set_output(&g_gpio_out_leds, CLKS_ENABLED, CLKS_OFF);

  // Main process

  UART_polled_tx_string(&g_uart_term, (const uint8_t*) g_MSG_INTRO);

  UART_polled_tx_string(&g_uart_term, (const uint8_t*) g_MSG_DEMO);

  initBITModule(&g_uart_term,
  						  &g_gpio_in_pbs,
								&g_gpio_out_leds,
								&g_gpio_Pan9320);

  do {
  	switch(State) {
			case STATE_IDLE: {
				break;
			}
			case STATE_BIT: {
				BIT_inProgress = 1;
	  		runAdvancedTests();
	  		BIT_inProgress = 0;
	  		UART_polled_tx_string(&g_uart_term, (const uint8_t*) g_MSG_DEMO);
	  		State = STATE_IDLE;
				break;
			}
			case STATE_MORSE1: {
				morse_status = (morse_status == 0 ? 1 : 0);
				if (morse_status == 1) {
					UART_polled_tx_string(&g_uart_term, (const uint8_t *) g_MSG_MORSE_ON);
		  		GPIO_set_output(&g_gpio_out_leds, LED1_GREEN, LED_OFF);
		  		GPIO_set_output(&g_gpio_out_leds, LED1_RED, LED_OFF);
		  		State = STATE_MORSE2;
				} else {
					UART_polled_tx_string(&g_uart_term, (const uint8_t *) g_MSG_MORSE_OFF);
					UART_polled_tx_string(&g_uart_term, (const uint8_t*) g_MSG_DEMO);
					State = STATE_IDLE;
				}
				break;
			}
			case STATE_MORSE2: {
				rx_count = UART_get_rx(&g_uart_term, &rx_char, 1);
				if (rx_count > 0) {
					UART_send(&g_uart_term, &rx_char, 1);
					transmitText(&g_gpio_out_leds, (char)rx_char);
				}
				break;
			}
			case STATE_CM1: {
				tstamp1 = count;
				State = STATE_CM2;
				break;
			}
			case STATE_CM2: {
				pb_read = GPIO_get_inputs(&g_gpio_in_pbs);
				pb_stable = ~pb_read & 0x00000002;
				if (pb_stable == 0x00000002) {
					if (count - tstamp1 > 4) {
						State = STATE_CM3;
					}
				} else {
					State = STATE_BIT;
					tstamp1 = 0;
				}
				break;
			}
			case STATE_CM3: {
				UART_polled_tx_string(&g_uart_term, (const uint8_t*) g_MSG_CM_TEST);
				BIT_inProgress = 2;
				runCMTests(&g_CM_PB_test);
				break;
			}
			default: {
				break;
			}
  	}
  } while (1);

  return 0;
}

/*-------------------------------------------------------------------------*//**
	Function to generate a millisecond-based delay
*/
void Delay (int msec) {

	uint32_t count = msec * TIMER_MS_REF;

	TMR_reload(&g_timer_delay, count);
	while (g_timer_irq != 1){}
	g_timer_irq = 0;
}



