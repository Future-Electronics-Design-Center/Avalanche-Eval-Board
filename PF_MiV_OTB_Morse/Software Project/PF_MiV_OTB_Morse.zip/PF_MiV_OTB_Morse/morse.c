/*******************************************************************************
 * Project     : PF_RISCV_OTB_Morse
 * File        : morse.c
 *
 * Description : This is a simple Morse code emitter that can take any defined
 * 							 character from the Morse standard and transmit it using a LED.
 * 							 The character is received through a serial terminal.
 *
 * Created on  : Feb 19, 2018
 * Author      : Frederic.Vachon  
 *
 * (c) Copyright 2018 Future Electronics - Advanced Engineering Group
 *     All rights reserved
 *
 * DISCLAIMER OF WARRANTY
 * All materials, information and services are provided “as-is” and “as-available”
 * for your use. Future Electronics disclaims all warranties of any kind, either
 * express or implied, including but not limited to, the implied warranties of
 * merchantability and fitness for a particular purpose, title, or non-infringement.
 * You acknowledge and agree that the reference designs and other such design
 * materials included herein are provided as an example only and that you will
 * exercise your own independent analysis and judgment in your use of these
 * materials. Future Electronics assumes no liability for your use of these
 * materials for your product designs.
 *
 * INDEMNIFICATION
 * You agree to indemnify, defend and hold Future Electronics and all of its
 * agents, directors, employees, information providers, licensors and licensees,
 * and affiliated companies (collectively, “Indemnified Parties”), harmless from
 * and against any and all liability and costs (including, without limitation,
 * attorneys’ fees and costs), incurred by the Indemnified Parties in connection
 * with any claim arising out of any breach by You of these Terms and Conditions
 * of Use or any representations or warranties made by You herein. You will
 * cooperate as fully as reasonably required in Future Electronics’ defense of
 * any claim. Future Electronics reserves the right, at its own expense, to
 * assume the exclusive defense and control of any matter otherwise subject to
 * indemnification by You and You shall not in any event settle any matter
 * without the written consent of Future Electronics.
 *
 * LIMITATION OF LIABILITY
 * Under no circumstances shall Future Electronics, nor its agents, directors,
 * employees, information providers, licensors and licensee, and affiliated
 * companies be liable for any damages, including without limitation, direct,
 * indirect, incidental, special, punitive, consequential, or other damages
 * (including without limitation lost profits, lost revenues, or similar economic
 * loss), whether in contract, tort, or otherwise, arising out of the use or
 * inability to use the materials provided as a reference design, even if we
 * are advised of the possibility thereof, nor for any claim by a third party.
 ******************************************************************************/

#include <stdio.h>
#include <ctype.h>
#include <string.h>

#include "global.h"
#include "morse.h"

#ifdef __cplusplus
extern "C" {
#endif

// --- Private functions declaration -------------------------------------------
void Dot(gpio_instance_t *gpio_leds);
void Dash(gpio_instance_t *gpio_leds);
void Encoder(char *inputStr, char *morseStr);

// --- Public Functions --------------------------------------------------------

void transmitText(gpio_instance_t *gpio_leds, char letter) {

	char txtToTransmit[5] = "";

	Encoder(&letter, txtToTransmit);

  for(int i = 0; i <= strlen(txtToTransmit); i++) {
    switch(txtToTransmit[i]) {
      case '.': //dit
        Dot(gpio_leds);
        break;
      case '-': //dah
        Dash(gpio_leds);
        break;
      case ' ': //gap
      	Delay(UNIT_LENGTH);
    }
  }
}


// --- Private Functions -------------------------------------------------------

/*-------------------------------------------------------------------------*//**
	Function to encode a character to Dot/Dash format using the MorseMap lookup
*/
void Encoder(char *inputStr, char *morseStr) {

  for(int j = 0; j < sizeof MorseMap / sizeof *MorseMap; ++j) {
    if(toupper((unsigned char)inputStr[0]) == MorseMap[j].letter) {
    	strcat(morseStr, MorseMap[j].code);
      break;
    }
  }
  strcat(morseStr, " ");
}

/*-------------------------------------------------------------------------*//**
	Function to emit a Dot
*/
void Dot(gpio_instance_t *gpio_leds) {
	GPIO_set_output(gpio_leds, LED1_RED, LED_ON);
	Delay(UNIT_LENGTH);
	GPIO_set_output(gpio_leds, LED1_RED, LED_OFF);
	Delay(UNIT_LENGTH);
}

/*-------------------------------------------------------------------------*//**
	Function to emit a Dash
*/
void Dash(gpio_instance_t *gpio_leds) {
	GPIO_set_output(gpio_leds, LED1_RED, LED_ON);
	Delay(3 * UNIT_LENGTH);
	GPIO_set_output(gpio_leds, LED1_RED, LED_OFF);
	Delay(UNIT_LENGTH);
}


#ifdef __cplusplus
}
#endif
