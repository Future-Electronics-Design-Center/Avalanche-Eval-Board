/*******************************************************************************
 * Project     : PL_RISCV_OTB_Morse
 * File        : morse.h
 *
 * Description : Contains some definitions required by the Morse emitter.
 *
 * Created on  : Feb 19, 2018
 * Author      : Frederic.Vachon
 *
 * (c) Copyright 2018 Future Electronics - Advanced Engineering Group
 *     All rights reserved
 *
 * DISCLAIMER OF WARRANTY
 * All materials, information and services are provided “as-is” and “as-available”
 * for your use. Future Electronics disclaims all warranties of any kind, either
 * express or implied, including but not limited to, the implied warranties of
 * merchantability and fitness for a particular purpose, title, or non-infringement.
 * You acknowledge and agree that the reference designs and other such design
 * materials included herein are provided as an example only and that you will
 * exercise your own independent analysis and judgment in your use of these
 * materials. Future Electronics assumes no liability for your use of these
 * materials for your product designs.
 *
 * INDEMNIFICATION
 * You agree to indemnify, defend and hold Future Electronics and all of its
 * agents, directors, employees, information providers, licensors and licensees,
 * and affiliated companies (collectively, “Indemnified Parties”), harmless from
 * and against any and all liability and costs (including, without limitation,
 * attorneys’ fees and costs), incurred by the Indemnified Parties in connection
 * with any claim arising out of any breach by You of these Terms and Conditions
 * of Use or any representations or warranties made by You herein. You will
 * cooperate as fully as reasonably required in Future Electronics’ defense of
 * any claim. Future Electronics reserves the right, at its own expense, to
 * assume the exclusive defense and control of any matter otherwise subject to
 * indemnification by You and You shall not in any event settle any matter
 * without the written consent of Future Electronics.
 *
 * LIMITATION OF LIABILITY
 * Under no circumstances shall Future Electronics, nor its agents, directors,
 * employees, information providers, licensors and licensee, and affiliated
 * companies be liable for any damages, including without limitation, direct,
 * indirect, incidental, special, punitive, consequential, or other damages
 * (including without limitation lost profits, lost revenues, or similar economic
 * loss), whether in contract, tort, or otherwise, arising out of the use or
 * inability to use the materials provided as a reference design, even if we
 * are advised of the possibility thereof, nor for any claim by a third party.
 ******************************************************************************/

#ifndef MORSE_H
#define MORSE_H

#ifdef __cplusplus
extern "C" {
#endif


// Define unit length (250ms)
#define UNIT_LENGTH    250

// Lookup table to encode character into morse code
static const struct {
	const char letter;
	const char *code;
} MorseMap[] = {

	{'A', ".-"		},
	{'B', "-..."	},
	{'C', "-.-."	},
	{'D', "-.."		},
	{'E', "."			},
	{'F', "..-."	},
	{'G', "--."		},
	{'H', "...."	},
	{'I', ".."		},
	{'J', ".---" 	},
	{'K', "-.-"		},
	{'L', ".-.."	},
	{'M', "--"		},
	{'N', "-."		},
	{'O', "---"		},
	{'P', ".--."	},
	{'Q', "--.-"	},
	{'R', ".-."		},
	{'S', "..."		},
	{'T', "-"			},
	{'U', "..-"		},
	{'V', "...-"	},
	{'W', ".--"		},
	{'X', "-..-"	},
	{'Y', "-.--"	},
	{'Z', "--.."	},
	{' ', "      "}, //Gap between word, seven units

	{'1', ".----" },
	{'2', "..---" },
	{'3', "...--" },
	{'4', "....-" },
	{'5', "....." },
	{'6', "-...." },
	{'7', "--..." },
	{'8', "---.." },
	{'9', "----." },
	{'0', "-----" },

	{'.', "·–·–·–"},
	{',', "--..--"},
	{'?', "..--.."},
	{'!', "-.-.--"},
	{':', "---..."},
	{';', "-.-.-."},
	{'(', "-.--." },
	{')', "-.--.-"},
	{'"', ".-..-."},
	{'@', ".--.-."},
	{'&', ".-..." },
};


// --- Public Functions --------------------------------------------------------

/*-------------------------------------------------------------------------*//**
  The transmitText() function takes the received character, encode it and use
  a LED to emit it.

  @param *gpio_leds
    A pointer to the board LEDs GPIO interface of the main program.

  @param letter
    The character to be encoded and transmit using the LED.

  @return
    none.

  */
void transmitText(gpio_instance_t *gpio_leds, char letter);


#ifdef __cplusplus
}
#endif

#endif // MORSE_H
