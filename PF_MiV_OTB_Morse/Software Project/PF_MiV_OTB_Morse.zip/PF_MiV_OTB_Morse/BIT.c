/*******************************************************************************
 * Project     : PF_MiV_OTB_Morse
 * File        : BIT.c
 *
 * Description : The Built-In Test currently validate the following peripherals:
 * 							 LEDs, Pushbuttons, Wifi module.
 *
 * Created on  : Feb 19, 2018
 * Author      : Frederic.Vachon  
 *
 * (c) Copyright 2018 Future Electronics - Advanced Engineering Group 
 *     All rights reserved
 *
 * DISCLAIMER OF WARRANTY
 * All materials, information and services are provided “as-is” and “as-available”
 * for your use. Future Electronics disclaims all warranties of any kind, either
 * express or implied, including but not limited to, the implied warranties of
 * merchantability and fitness for a particular purpose, title, or non-infringement.
 * You acknowledge and agree that the reference designs and other such design
 * materials included herein are provided as an example only and that you will
 * exercise your own independent analysis and judgment in your use of these
 * materials. Future Electronics assumes no liability for your use of these
 * materials for your product designs.
 *
 * INDEMNIFICATION
 * You agree to indemnify, defend and hold Future Electronics and all of its
 * agents, directors, employees, information providers, licensors and licensees,
 * and affiliated companies (collectively, “Indemnified Parties”), harmless from
 * and against any and all liability and costs (including, without limitation,
 * attorneys’ fees and costs), incurred by the Indemnified Parties in connection
 * with any claim arising out of any breach by You of these Terms and Conditions 
 * of Use or any representations or warranties made by You herein. You will
 * cooperate as fully as reasonably required in Future Electronics’ defense of
 * any claim. Future Electronics reserves the right, at its own expense, to
 * assume the exclusive defense and control of any matter otherwise subject to
 * indemnification by You and You shall not in any event settle any matter
 * without the written consent of Future Electronics.
 *
 * LIMITATION OF LIABILITY
 * Under no circumstances shall Future Electronics, nor its agents, directors,
 * employees, information providers, licensors and licensee, and affiliated
 * companies be liable for any damages, including without limitation, direct,
 * indirect, incidental, special, punitive, consequential, or other damages
 * (including without limitation lost profits, lost revenues, or similar economic
 * loss), whether in contract, tort, or otherwise, arising out of the use or
 * inability to use the materials provided as a reference design, even if we
 * are advised of the possibility thereof, nor for any claim by a third party.
 ******************************************************************************/

#include "global.h"
#include "BIT.h"
#include "Pan9320.h"

// --- Private functions declaration -------------------------------------------

int Test_LEDs();
int Test_PBs();
int Test_Wifi();


const char *g_MSG_BIT_START = "\n\rExecute Built-in Test\n\r";
const char *g_MSG_BIT_RESET = "\n\rBuilt-in Test reset...\n\r";
const char *g_MSG_BIT_PASSED = "\n\rBuilt-in Test successful!\n\r";
const char *g_MSG_BIT_FAILED = "\n\rBuilt-in Test failed!\n\r";

const char *g_MSG_LED_START = "  1- LED test started\n\r";
const char *g_MSG_LED_PASSED = "  2- LED test passed\n\r";
const char *g_MSG_LED_FAILED = "  2- LED test failed\n\r";

const char *g_MSG_PB_START = "\n\r  1- Pushbuttons test started\n\r";
const char *g_MSG_PB_PASSED = "\n\r  2- Pushbuttons test completed\n\r";
const char *g_MSG_PB1_TEST = "\n\r    Press PB#1 to activate LED 1 Green\n\r";
const char *g_MSG_PB2_TEST = "\n\r    Press PB#2 to activate LED 2 Green\n\r";
const char *g_MSG_PB1_DEPRESSED = "      PB#1 depressed\n\r";
const char *g_MSG_PB2_DEPRESSED = "      PB#2 depressed\n\r";

const char *g_MSG_WIFI_ON = "\n\r  1- Wifi module ON for 10 seconds\n\r";
const char *g_MSG_WIFI_OFF = "  2- Wifi module Off\n\r";

static UART_instance_t *UART_term;
static gpio_instance_t *GPIO_in_pbs;
static gpio_instance_t *GPIO_out_leds;
static gpio_instance_t *GPIO_Pan9320;


// --- Public Functions --------------------------------------------------------

void initBITModule(
		UART_instance_t *g_uart_term,
		gpio_instance_t *g_gpio_in_pbs,
		gpio_instance_t *g_gpio_out_leds,
		gpio_instance_t *g_gpio_Pan9320) {

	UART_term = g_uart_term;
	GPIO_in_pbs = g_gpio_in_pbs;
	GPIO_out_leds = g_gpio_out_leds;
	GPIO_Pan9320 = g_gpio_Pan9320;
}


void runCMTests(uint8_t *g_CM_PB_test) {

	uint32_t pb_read;
	uint32_t pb_stable;

	// Wifi activated
	GPIO_set_output(GPIO_Pan9320, RESETn, RESET_OFF);

	// Activate external clocks outputs
	GPIO_set_output(GPIO_out_leds, CLKS_ENABLED, CLKS_ON);

	// PBs test
	while (1) {
		pb_read = GPIO_get_inputs(GPIO_in_pbs);
		pb_stable = ~pb_read & 0x00000003;
		if (pb_stable == 0x00000001) {
			*g_CM_PB_test = 1;
			GPIO_set_output(GPIO_out_leds, LED2_GREEN, LED_OFF);
			GPIO_set_output(GPIO_out_leds, LED2_RED, LED_OFF);
			GPIO_set_output(GPIO_out_leds, LED1_GREEN, LED_ON);
			Delay(1000);
			GPIO_set_output(GPIO_out_leds, LED1_GREEN, LED_OFF);
			GPIO_set_output(GPIO_out_leds, LED1_RED, LED_ON);
			Delay(1000);
			GPIO_set_output(GPIO_out_leds, LED1_RED, LED_OFF);
			*g_CM_PB_test = 0;
		}
		if (pb_stable == 0x00000002) {
			*g_CM_PB_test = 1;
			GPIO_set_output(GPIO_out_leds, LED1_GREEN, LED_OFF);
			GPIO_set_output(GPIO_out_leds, LED1_RED, LED_OFF);
			GPIO_set_output(GPIO_out_leds, LED2_GREEN, LED_ON);
			Delay(1000);
			GPIO_set_output(GPIO_out_leds, LED2_GREEN, LED_OFF);
			GPIO_set_output(GPIO_out_leds, LED2_RED, LED_ON);
			Delay(1000);
			GPIO_set_output(GPIO_out_leds, LED2_RED, LED_OFF);
			*g_CM_PB_test = 0;
		}
	}
}



void runBasicTests() {

	UART_polled_tx_string(UART_term, (const uint8_t *) g_MSG_BIT_START);

	// LEDs test
	UART_polled_tx_string(UART_term, (const uint8_t *) g_MSG_LED_START);
	Test_LEDs();
	UART_polled_tx_string(UART_term, (const uint8_t *) g_MSG_LED_PASSED);

	// Wifi Test
	UART_polled_tx_string(UART_term, (const uint8_t *) g_MSG_WIFI_ON);
	Test_Wifi();
	UART_polled_tx_string(UART_term, (const uint8_t *) g_MSG_WIFI_OFF);

	UART_polled_tx_string(UART_term, (const uint8_t *) g_MSG_BIT_PASSED);
}


void runAdvancedTests() {

	UART_polled_tx_string(UART_term, (const uint8_t *) g_MSG_BIT_START);

	// LEDs test
	UART_polled_tx_string(UART_term, (const uint8_t *) g_MSG_LED_START);
	Test_LEDs();
	UART_polled_tx_string(UART_term, (const uint8_t *) g_MSG_LED_PASSED);

	// Pushbuttons test
	UART_polled_tx_string(UART_term, (const uint8_t *) g_MSG_PB_START);
	Test_PBs();
	UART_polled_tx_string(UART_term, (const uint8_t *) g_MSG_PB_PASSED);

	// Wifi Test
	UART_polled_tx_string(UART_term, (const uint8_t *) g_MSG_WIFI_ON);
	Test_Wifi();
	UART_polled_tx_string(UART_term, (const uint8_t *) g_MSG_WIFI_OFF);

	UART_polled_tx_string(UART_term, (const uint8_t *) g_MSG_BIT_PASSED);
}


// --- Private Functions -------------------------------------------------------

/*-------------------------------------------------------------------------*//**
	Function to test both colors of the two user LEDs.
		* Schematic LED 1 = PCB LED 4
		* Schematic LED 2 = PCB LED 5
	The LEDs will be lit in the following order: LED 1 green, LED 1 red,
	LED 2 green, LED 2 red.
*/
int Test_LEDs() {

	int success = 1;

	GPIO_set_output(GPIO_out_leds, LED1_GREEN, LED_OFF);
	GPIO_set_output(GPIO_out_leds, LED1_RED, LED_OFF);
	GPIO_set_output(GPIO_out_leds, LED2_GREEN, LED_OFF);
	GPIO_set_output(GPIO_out_leds, LED2_RED, LED_OFF);

	for (int i = 0; i < 2; i++) {
		Delay(1000);
		GPIO_set_output(GPIO_out_leds, LED1_GREEN, LED_ON);
		Delay(1000);
		GPIO_set_output(GPIO_out_leds, LED1_GREEN, LED_OFF);
		GPIO_set_output(GPIO_out_leds, LED1_RED, LED_ON);
		Delay(1000);
		GPIO_set_output(GPIO_out_leds, LED1_RED, LED_OFF);
		GPIO_set_output(GPIO_out_leds, LED2_GREEN, LED_ON);
		Delay(1000);
		GPIO_set_output(GPIO_out_leds, LED2_GREEN, LED_OFF);
		GPIO_set_output(GPIO_out_leds, LED2_RED, LED_ON);
		Delay(1000);
		GPIO_set_output(GPIO_out_leds, LED2_RED, LED_OFF);
	}
	return success;
}

/*-------------------------------------------------------------------------*//**
	Function to test the user pushbuttons (SW1 and SW2)
*/
int Test_PBs() {

	int success = 1;
	uint32_t pb_read;
	uint32_t pb_stable;

	GPIO_set_output(GPIO_out_leds, LED1_GREEN, LED_OFF);
	GPIO_set_output(GPIO_out_leds, LED1_RED, LED_OFF);
	GPIO_set_output(GPIO_out_leds, LED2_GREEN, LED_OFF);
	GPIO_set_output(GPIO_out_leds, LED2_RED, LED_OFF);

	UART_polled_tx_string(UART_term, (const uint8_t *) g_MSG_PB1_TEST);
	for (;;) {
		pb_read = GPIO_get_inputs(GPIO_in_pbs);
		pb_stable = ~pb_read & 0x00000001;
		if (pb_stable == 0x00000001) {
			GPIO_set_output(GPIO_out_leds, LED1_GREEN, LED_ON);
			UART_polled_tx_string(UART_term, (const uint8_t *) g_MSG_PB1_DEPRESSED);
			Delay(1000);
			GPIO_set_output(GPIO_out_leds, LED1_GREEN, LED_OFF);
			break;
		}
	}

	UART_polled_tx_string(UART_term, (const uint8_t *) g_MSG_PB2_TEST);
	for (;;) {
		pb_read = GPIO_get_inputs(GPIO_in_pbs);
		pb_stable = ~pb_read & 0x00000002;
		if (pb_stable == 0x00000002) {
			GPIO_set_output(GPIO_out_leds, LED2_GREEN, LED_ON);
			UART_polled_tx_string(UART_term, (const uint8_t *) g_MSG_PB2_DEPRESSED);
			Delay(1000);
			GPIO_set_output(GPIO_out_leds, LED2_GREEN, LED_OFF);
			break;
		}
	}
	return success;
}

/*-------------------------------------------------------------------------*//**
	Function to test the Wifi module. By removing the reset signal on the Wifi
	module, it will boot up and activate its Access Point broadcasting.
	  - LED 6 is active when broadcasting
	  - LED 7 lit up after reset is released then LED 10 should become solid
	  - LED 9 is an heartbeat
*/
int Test_Wifi() {

	int success = 1;

	GPIO_set_output(GPIO_Pan9320, RESETn, RESET_OFF);
	Delay(10000);
	GPIO_set_output(GPIO_Pan9320, RESETn, RESET_ON);

	return success;
}




