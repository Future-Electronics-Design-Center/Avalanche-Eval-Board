/*******************************************************************************
 * Project     : PF_MiV_ADC_Demo
 * File        : MCP39x3.c
 *
 * Description : This file contains a definition for a basic ADC module
 *               interface.
 *
 * Created on  : Mar 15, 2018
 * Author      : Frederic.Vachon  
 *
 * (c) Copyright 2018 Future Electronics - Advanced Engineering Group 
 *     All rights reserved
 *
 * DISCLAIMER OF WARRANTY
 * All materials, information and services are provided “as-is” and “as-available”
 * for your use. Future Electronics disclaims all warranties of any kind, either
 * express or implied, including but not limited to, the implied warranties of
 * merchantability and fitness for a particular purpose, title, or non-infringement.
 * You acknowledge and agree that the reference designs and other such design
 * materials included herein are provided as an example only and that you will
 * exercise your own independent analysis and judgment in your use of these
 * materials. Future Electronics assumes no liability for your use of these
 * materials for your product designs.
 *
 * INDEMNIFICATION
 * You agree to indemnify, defend and hold Future Electronics and all of its
 * agents, directors, employees, information providers, licensors and licensees,
 * and affiliated companies (collectively, “Indemnified Parties”), harmless from
 * and against any and all liability and costs (including, without limitation,
 * attorneys’ fees and costs), incurred by the Indemnified Parties in connection
 * with any claim arising out of any breach by You of these Terms and Conditions 
 * of Use or any representations or warranties made by You herein. You will
 * cooperate as fully as reasonably required in Future Electronics’ defense of
 * any claim. Future Electronics reserves the right, at its own expense, to
 * assume the exclusive defense and control of any matter otherwise subject to
 * indemnification by You and You shall not in any event settle any matter
 * without the written consent of Future Electronics.
 *
 * LIMITATION OF LIABILITY
 * Under no circumstances shall Future Electronics, nor its agents, directors,
 * employees, information providers, licensors and licensee, and affiliated
 * companies be liable for any damages, including without limitation, direct,
 * indirect, incidental, special, punitive, consequential, or other damages
 * (including without limitation lost profits, lost revenues, or similar economic
 * loss), whether in contract, tort, or otherwise, arising out of the use or
 * inability to use the materials provided as a reference design, even if we
 * are advised of the possibility thereof, nor for any claim by a third party.
 ******************************************************************************/

#include "MCP39x3.h"
#include "core_gpio.h"
#include "core_spi.h"

// -- Definitions --------------------------------------------------------------
#define MCP39x3_SPI_ADDR 			0x00000000UL
#define MCP39x3_GPIO_ADDR 		0x00000100UL

#define ADC_RSTn		    			GPIO_0
#define ADC_RST_ON		  			0
#define ADC_RST_OFF	    			1

#define ADC_CSn								GPIO_1
#define ADC_CSn_SET						0
#define ADC_CSn_RESET					1

#define ADC_GPIO              &g_gpio_ADC
#define ADC_SPI               &g_spi_ADC


static gpio_instance_t g_gpio_ADC;
static spi_instance_t g_spi_ADC;

// --- Private functions -------------------------------------------------------

/*-------------------------------------------------------------------------*//**
	Function to set the Chip Select signal of the MCP93x3.
*/
void setCS() {
	GPIO_set_output(ADC_GPIO, ADC_CSn, ADC_CSn_SET);
}

/*-------------------------------------------------------------------------*//**
	Function to reset the Chip Select signal of the MCP93x3.
*/
void resetCS() {
	GPIO_set_output(ADC_GPIO, ADC_CSn, ADC_CSn_RESET);
}

/*-------------------------------------------------------------------------*//**
	Function to read one register of the MCP93x3 ADC. All reading generate
	a 24 bits value that will be right justified in the returned value.
*/
uint32_t read_register(uint8_t cmd) {

	uint32_t result = 0;
	uint8_t read_buffer[3];

	setCS();
	SPI_transfer_block(ADC_SPI, &cmd, 1, read_buffer,sizeof(read_buffer));
	resetCS();

	result = read_buffer[0] << 16;
	result |= read_buffer[1] << 8;
	result |= read_buffer[2];

	return result;
}

/*-------------------------------------------------------------------------*//**
	Function to write one register of the MCP93x3 ADC. The 24 bits input data
	shall	be right justified to be sent properly to the ADC.
*/
void write_register(uint8_t cmd, uint32_t data) {

	uint8_t data_buffer[3];

	data_buffer[0] = (data & 0xff0000) >> 16;
	data_buffer[1] = (data & 0x00ff00) >> 8;
	data_buffer[2] = (data & 0x0000ff);

	setCS();
	SPI_transfer_block(ADC_SPI, &cmd, 1, 0, 0);
	SPI_transfer_block(ADC_SPI, data_buffer, sizeof(data_buffer), 0, 0);
	resetCS();
}

// --- Public Functions --------------------------------------------------------

void init_ADC(addr_t interface_addr) {

	GPIO_init(ADC_GPIO,	interface_addr | MCP39x3_GPIO_ADDR,	GPIO_APB_32_BITS_BUS);
	SPI_init(ADC_SPI, interface_addr | MCP39x3_SPI_ADDR, 32);
	SPI_configure_master_mode(ADC_SPI);
	enable_ADC();
}

void disable_ADC() {
	GPIO_set_output(ADC_GPIO, ADC_RSTn, ADC_RST_ON);
}

void enable_ADC() {
	GPIO_set_output(ADC_GPIO, ADC_RSTn, ADC_RST_OFF);
}

void reset_ADC() {
	GPIO_set_output(ADC_GPIO, ADC_RSTn, ADC_RST_ON);
	for (volatile uint16_t i = 500 ; i > 0; i--);
	GPIO_set_output(ADC_GPIO, ADC_RSTn, ADC_RST_OFF);
}

uint32_t read_ADC_channel(uint8_t cmd) {
	return (read_register(cmd));
}

uint32_t read_ADC_config() {
	return (read_register(READ_CONFIG));
}

uint32_t read_ADC_status() {
	return (read_register(READ_STATUS));
}

// set to 24 bits mode and output
uint8_t set_Channels_24bits() {

	uint8_t result = 1;
	uint32_t data_in = 0;
	uint32_t data_out = 0;

	data_in = read_register(READ_CONFIG);
	data_in |= 0x3F << 18; 			// Reset all 6 channels
	write_register(WRITE_CONFIG, data_in);

	data_in &= ~(0x3F << 18); 	// Remove reset on all channels
	data_in |= OSR_256 << 4;		// set OSR to 256
	write_register(WRITE_CONFIG, data_in);
	data_out = read_register(READ_CONFIG);

	if (data_in != data_out) result = 0;

	data_in = read_register(READ_STATUS);
	data_in |= 0x3F << 15; // Set Width to 24 bits
	write_register(WRITE_STATUS, data_in);

	return result;
}

uint8_t set_Channels_16bits() {

	uint8_t result = 1;
	uint32_t data_in = 0;
	uint32_t data_out = 0;

	data_in = read_register(READ_CONFIG);
	data_in |= 0x3F << 18; 			// Reset all 6 channels
	write_register(WRITE_CONFIG, data_in);

	data_in &= ~(0x3F << 18); 	// Remove reset on all channels
	data_in &= ~(0x3 << 4);     // clear current OSR
	data_in |= OSR_64 << 4;			// set OSR to 64
	write_register(WRITE_CONFIG, data_in);
	data_out = read_register(READ_CONFIG);

	if (data_in != data_out) result = 0;

	data_in = read_register(READ_STATUS);
	data_in &= ~(0x3F << 15); // Set Width to 16 bits
	write_register(WRITE_STATUS, data_in);

	return result;
}







