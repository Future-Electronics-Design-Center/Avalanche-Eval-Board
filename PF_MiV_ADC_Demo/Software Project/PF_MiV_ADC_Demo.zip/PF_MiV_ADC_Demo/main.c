/*******************************************************************************
 * Project     : PF_MiV_ADC_Demo
 * File        : main.c
 *
 * Description : The Avalanche ADC demo features the MCP93x3 block interface
 * 							 used with a Mi-V softcore. The program is very simple.
 *
 * 							 Upon power-up of the board, an heartbeat will start on LED2
 * 							 green. Both pushbuttons will give you the capability to
 * 							 sample an applied voltage between 0 and 784 mV to ADC
 * 							 channel 0 (PB#1) or channel 2 (PB#2). Sampling is done with
 * 							 a 24 bits resolution. Results are send to a host computer
 * 							 running a serial terminal.
 *
 * 							 Terminal setup: Serial Terminal, 115200/8/1, no parity,
 * 							 no flow control.
 *
 * Created on  : Mar 20, 2018
 * Author      : Frederic.Vachon  
 *
 * (c) Copyright 2018 Future Electronics - Advanced Engineering Group
 *     All rights reserved
 *
 * DISCLAIMER OF WARRANTY
 * All materials, information and services are provided “as-is” and “as-available”
 * for your use. Future Electronics disclaims all warranties of any kind, either
 * express or implied, including but not limited to, the implied warranties of
 * merchantability and fitness for a particular purpose, title, or non-infringement.
 * You acknowledge and agree that the reference designs and other such design
 * materials included herein are provided as an example only and that you will
 * exercise your own independent analysis and judgment in your use of these
 * materials. Future Electronics assumes no liability for your use of these
 * materials for your product designs.
 *
 * INDEMNIFICATION
 * You agree to indemnify, defend and hold Future Electronics and all of its
 * agents, directors, employees, information providers, licensors and licensees,
 * and affiliated companies (collectively, “Indemnified Parties”), harmless from
 * and against any and all liability and costs (including, without limitation,
 * attorneys’ fees and costs), incurred by the Indemnified Parties in connection
 * with any claim arising out of any breach by You of these Terms and Conditions 
 * of Use or any representations or warranties made by You herein. You will
 * cooperate as fully as reasonably required in Future Electronics’ defense of
 * any claim. Future Electronics reserves the right, at its own expense, to
 * assume the exclusive defense and control of any matter otherwise subject to
 * indemnification by You and You shall not in any event settle any matter
 * without the written consent of Future Electronics.
 *
 * LIMITATION OF LIABILITY
 * Under no circumstances shall Future Electronics, nor its agents, directors,
 * employees, information providers, licensors and licensee, and affiliated
 * companies be liable for any damages, including without limitation, direct,
 * indirect, incidental, special, punitive, consequential, or other damages
 * (including without limitation lost profits, lost revenues, or similar economic
 * loss), whether in contract, tort, or otherwise, arising out of the use or
 * inability to use the materials provided as a reference design, even if we
 * are advised of the possibility thereof, nor for any claim by a third party.
 ******************************************************************************/
#include <stdio.h>
#include <string.h>

#include "global.h"
#include "MCP39x3.h"

// -- Constants --------------------------------------------------------------
const char *g_MSG_INTRO =
		"\n\r(C) Copyright 2018 Future Electronics - Avalanche Board\n\r";

const char *g_MSG_DEMO =
		"\n\rMCP9303 Simple Demo"
		"\n\r  Voltage input range: 0 to ~784 mV\n\r"
		"\n\r  Press PB1 to sample ADC channel 0 voltage"
		"\n\r  Press PB2 to sample ADC channel 2 voltage\n\r";

const char *g_MSG_CH0_VALUE =
		"\n\rThe value in channel 0 is: %d mV";

const char *g_MSG_CH2_VALUE =
		"\n\rThe value in channel 2 is: %d mV";


#define STATE_IDLE			0x01
#define STATE_READ_CH0	0x02
#define STATE_READ_CH2  0x03


// -- UART instance data -----------------------------------------------------
UART_instance_t g_uart_term;

// -- GPIO instance data -----------------------------------------------------
gpio_instance_t g_gpio_in_pbs;
gpio_instance_t g_gpio_out_leds;

// -- Global variables -------------------------------------------------------
static uint8_t State;

/*----------------------------------------------------------------------------
 * System Tick Interrupt Handler (Heartbeat)
 */
void SysTick_Handler(void) {

	uint32_t gpio_pattern_leds;

	// LED 2 Green heartbeat
	gpio_pattern_leds = GPIO_get_outputs(&g_gpio_out_leds);
	gpio_pattern_leds &= 0x00000010;
	if (gpio_pattern_leds == 0x0) { 		// LED on?
		GPIO_set_output(&g_gpio_out_leds, LED2_GREEN, LED_OFF);
	} else {
		GPIO_set_output(&g_gpio_out_leds, LED2_GREEN, LED_ON);
	}
}

/*----------------------------------------------------------------------------
 * User Pushbutton #1 Interrupt Handler (Read ADC channel 0)
 */
void External_31_IRQHandler() {
	State = STATE_READ_CH0;
	GPIO_clear_irq(&g_gpio_in_pbs, PB1);
	PLIC_CompleteIRQ(PLIC_ClaimIRQ());
}

/*----------------------------------------------------------------------------
 * User Pushbutton #2 Interrupt Handler (Read ADC channel 2)
 */
void External_30_IRQHandler() {
	State = STATE_READ_CH2;
	GPIO_clear_irq(&g_gpio_in_pbs, PB2);
	PLIC_CompleteIRQ(PLIC_ClaimIRQ());
}


/*----------------------------------------------------------------------------
 * main
 */
int main() {

	int32_t ch0_reg_value;
	int32_t ch2_reg_value;
	int32_t temp_value;
	char valueStr[50];

	State = STATE_IDLE;

 	// -- PLIC controller setup --------------------------------------------------

  PLIC_init();

 	PLIC_SetPriority(IRQ30_PB1, 1);
 	PLIC_EnableIRQ(IRQ30_PB1);

 	PLIC_SetPriority(IRQ29_PB2, 2);
 	PLIC_EnableIRQ(IRQ29_PB2);

 	// -- GPIO setup -------------------------------------------------------------

 	GPIO_init(&g_gpio_in_pbs, COREGPIO_BASIC_ADDR, GPIO_APB_32_BITS_BUS);
 	GPIO_init(&g_gpio_out_leds, COREGPIO_BASIC_ADDR, GPIO_APB_32_BITS_BUS);

  // User PB#1
  GPIO_config(&g_gpio_in_pbs, PB1, GPIO_INPUT_MODE | GPIO_IRQ_EDGE_POSITIVE);
  GPIO_enable_irq(&g_gpio_in_pbs, PB1);
  // User PB#2
  GPIO_config(&g_gpio_in_pbs, PB2, GPIO_INPUT_MODE | GPIO_IRQ_EDGE_NEGATIVE);
  GPIO_enable_irq(&g_gpio_in_pbs, PB2);
  // LED 1
  GPIO_config(&g_gpio_out_leds, LED1_GREEN, GPIO_OUTPUT_MODE);
  GPIO_config(&g_gpio_out_leds, LED1_RED, GPIO_OUTPUT_MODE);

  GPIO_set_output(&g_gpio_out_leds, LED1_GREEN, LED_OFF);
  GPIO_set_output(&g_gpio_out_leds, LED1_RED, LED_OFF);

  // LED 2
  GPIO_config(&g_gpio_out_leds, LED2_GREEN, GPIO_OUTPUT_MODE);
  GPIO_config(&g_gpio_out_leds, LED2_RED, GPIO_OUTPUT_MODE);

  GPIO_set_output(&g_gpio_out_leds, LED2_GREEN, LED_OFF);
  GPIO_set_output(&g_gpio_out_leds, LED2_RED, LED_OFF);

  // Terminal UART setup
  UART_init(&g_uart_term,
  					COREUART_TERM_ADDR,
						BAUD_VALUE_115200,
            (DATA_8_BITS | NO_PARITY));

  // MCP3903 setup (ADC)
  init_ADC(COREGPIO_MCP9303_ADDR);
  set_Channels_24bits();

  // System Timer setup
  SysTick_Config(SYS_CLK_FREQ/2);

  // Main process

  UART_polled_tx_string(&g_uart_term, (const uint8_t*) g_MSG_INTRO);

  UART_polled_tx_string(&g_uart_term, (const uint8_t*) g_MSG_DEMO);


  do {
  	switch(State) {
			case STATE_IDLE: {
				break;
			}
			case STATE_READ_CH0: {
				ch0_reg_value -= ch0_reg_value;
				ch0_reg_value = read_ADC_channel(READ_CH0);
				temp_value = ch0_reg_value / 3; 	// Default ADC Gain
				temp_value = temp_value / 3570; 	// ~1mV (Vref: 2.35V)

				sprintf(valueStr, g_MSG_CH0_VALUE, temp_value);
				UART_polled_tx_string(&g_uart_term, (const uint8_t*) valueStr);
	  		State = STATE_IDLE;
				break;
			}
			case STATE_READ_CH2: {
				ch2_reg_value -= ch2_reg_value;
				ch2_reg_value = read_ADC_channel(READ_CH2);
				temp_value = ch2_reg_value / 3; 	// Default ADC Gain
				temp_value = temp_value / 3570; 	// ~1mV (Vref: 2.35V)

				sprintf(valueStr, g_MSG_CH2_VALUE, temp_value);
				UART_polled_tx_string(&g_uart_term, (const uint8_t*) valueStr);
	  		State = STATE_IDLE;
				break;
			}
			default: {
				break;
			}
  	}
  } while (1);

  return 0;
}






